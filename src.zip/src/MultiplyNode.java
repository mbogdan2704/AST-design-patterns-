
public  class MultiplyNode implements SimpleNode{
	String type;
	MultiplyNode(String type)
	{
		this.type = type;
	}
	@Override
	public String getType()
	{
		return this.type;
	}
	
}

