
public interface SimpleNode {
	String getType();

}
